import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, onAuthStateChanged, User } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, collection, addDoc, onSnapshot } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);
export const googleProvider = new GoogleAuthProvider();

export const loginWithGoogle = async () => {
  try {
    const result = await signInWithPopup(auth, googleProvider);
    return result.user;
  } catch (error) {
    console.error('Login error:', error);
    throw error;
  }
};

export const logout = () => auth.signOut();

export interface UserData {
  isPaid: boolean;
  trialStart: number;
}

export const syncUser = (user: User, callback: (data: UserData) => void) => {
  const userRef = doc(db, 'users', user.uid);
  
  return onSnapshot(userRef, (snapshot) => {
    if (snapshot.exists()) {
      callback(snapshot.data() as UserData);
    } else {
      const initialData: UserData = {
        isPaid: false,
        trialStart: Date.now()
      };
      setDoc(userRef, initialData);
      callback(initialData);
    }
  });
};

export const submitPayment = async (userId: string, tid: string, method: string) => {
  return addDoc(collection(db, 'payments'), {
    userId,
    tid,
    method,
    status: 'pending',
    timestamp: Date.now()
  });
};
