import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY as string });

export interface BusinessLead {
  name: string;
  address: string;
  phone: string;
  niche: string;
  hasWebsite: boolean;
  confidenceScore: number;
  contactStrategy: string;
  whyNoWebsite: string;
  availableInfo: string[];
}

export async function findNoWebBusinesses(niche: string, location: string): Promise<BusinessLead[]> {
  const prompt = `Search for businesses in the "${niche}" industry located in "${location}". 
  Your primary goal is to find businesses that DO NOT have an official professional website. 
  
  For each business:
  1. Verify if they have an official website (social media pages like Facebook/Instagram don't count as an official website).
  2. If they have a Google Maps listing but the "Website" field is empty or missing, they are a high-quality lead.
  3. Extract their phone number and full address.
  4. Provide a "Contact Strategy" (e.g., "Call during morning hours" or "Visit in person since they have a physical storefront").
  5. List what information is available about them (e.g., "Google Maps listing", "Yelp reviews", "Facebook page").
  
  Only include businesses where you are highly confident they lack a dedicated website.
  Return the results as a JSON array.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              address: { type: Type.STRING },
              phone: { type: Type.STRING },
              niche: { type: Type.STRING },
              hasWebsite: { type: Type.BOOLEAN },
              confidenceScore: { type: Type.NUMBER, description: "Confidence scale 0-100 that they definitely don't have a website" },
              contactStrategy: { type: Type.STRING },
              whyNoWebsite: { type: Type.STRING, description: "Reason why you think they don't have a website (e.g. search found only directory listings)" },
              availableInfo: { 
                type: Type.ARRAY, 
                items: { type: Type.STRING },
                description: "List of platforms where this business is found (e.g. Google Maps, Yelp, Yellow Pages)"
              },
            },
            required: ["name", "address", "phone", "hasWebsite", "confidenceScore", "contactStrategy", "whyNoWebsite", "availableInfo"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) return [];
    
    // Filter to only include those without websites (safety check)
    const leads: BusinessLead[] = JSON.parse(text);
    return leads.filter(lead => !lead.hasWebsite || lead.confidenceScore > 80);
  } catch (error) {
    console.error("Lead Generation Error:", error);
    return [];
  }
}

export interface BusinessReview {
  name: string;
  niche: string;
  description: string;
  services: string[];
  operatingHours: string;
  location: string;
  contact: {
    phone: string;
    email: string;
    social: string[];
  };
  keyFeatures: string[];
  targetAudience: string;
  suggestedHeroText: string;
  suggestedSubtext: string;
}

export async function reviewBusinessFromUrl(url: string): Promise<BusinessReview | null> {
  const prompt = `Review the business located at this Google Maps URL or search link: ${url}.
  I need a comprehensive breakdown of this local business to help build them a professional website.
  
  Search for:
  - Business name and specific niche.
  - Detailed description of what they do.
  - List of services they offer.
  - Operating hours and physical location.
  - Any contact info (phone, email, social media links).
  - Key selling points or unique features found in reviews or photos.
  - Target audience description.
  - A suggested 'Hero Headline' and 'Subtext' for their new website.

  Return the result as a single JSON object.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            niche: { type: Type.STRING },
            description: { type: Type.STRING },
            services: { type: Type.ARRAY, items: { type: Type.STRING } },
            operatingHours: { type: Type.STRING },
            location: { type: Type.STRING },
            contact: {
              type: Type.OBJECT,
              properties: {
                phone: { type: Type.STRING },
                email: { type: Type.STRING },
                social: { type: Type.ARRAY, items: { type: Type.STRING } }
              },
              required: ["phone", "email", "social"]
            },
            keyFeatures: { type: Type.ARRAY, items: { type: Type.STRING } },
            targetAudience: { type: Type.STRING },
            suggestedHeroText: { type: Type.STRING },
            suggestedSubtext: { type: Type.STRING }
          },
          required: ["name", "niche", "description", "services", "operatingHours", "location", "contact", "keyFeatures", "targetAudience", "suggestedHeroText", "suggestedSubtext"]
        }
      }
    });

    const text = response.text;
    if (!text) return null;
    return JSON.parse(text);
  } catch (error) {
    console.error("Business Review Error:", error);
    return null;
  }
}
