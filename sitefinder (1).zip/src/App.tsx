/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Search, MapPin, Phone, Globe, ShieldAlert, CheckCircle2, Loader2, Info, Send, Building2, Layout, Link as LinkIcon, Code, Copy, Sparkles, Rocket, CreditCard, Landmark, ArrowRight, ShieldCheck, Zap, X, Coins, Bitcoin, LogIn, LogOut, User as UserIcon } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { findNoWebBusinesses, BusinessLead, reviewBusinessFromUrl, BusinessReview } from './services/geminiService';
import { auth, loginWithGoogle, logout, syncUser, submitPayment, UserData } from './lib/firebase';
import { User } from 'firebase/auth';

// --- Custom Checkout Component ---
const CheckoutPage = ({ user, onClose, onPaymentSuccess, iban }: { user: User | null, onClose: () => void, onPaymentSuccess: () => void, iban: string }) => {
  const [step, setStep] = useState(1);
  const [method, setMethod] = useState<'jazz' | 'crypto' | 'card'>('jazz');
  const [tid, setTid] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const maskedIban = iban.slice(0, 11) + "**********" + iban.slice(-4);

  const handleVerify = async () => {
    if (!tid || !user) return;
    setIsVerifying(true);
    
    // Notify Webhook & Database
    try {
      await submitPayment(user.uid, tid, method);
      const webhook = (process.env.PAYMENT_WEBHOOK_URL || '').trim();
      if (webhook) {
        await fetch(webhook, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            uid: user.uid,
            email: user.email,
            tid,
            method,
            iban,
            timestamp: new Date().toISOString(),
            status: 'pending_confirmation'
          })
        });
      }
    } catch (e) { console.error('Submission failed', e); }

    // Mock verification delay - Real confirmation happens via you!
    setTimeout(() => {
      setIsVerifying(false);
      onClose();
      alert("Submission received! We'll confirm your Elite status within 30-60 mins. Please check back soon.");
    }, 2500);
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-[100] flex items-center justify-center p-4 md:p-6 bg-slate-950/60 backdrop-blur-md overflow-hidden"
    >
      <motion.div 
        initial={{ scale: 0.9, y: 40 }} animate={{ scale: 1, y: 0 }}
        className="bg-white w-full max-w-4xl rounded-[40px] shadow-[0_32px_128px_rgba(0,0,0,0.2)] flex flex-col md:flex-row max-h-[90vh] overflow-hidden border border-white/20"
      >
        {/* Left Side: Order Summary */}
        <div className="md:w-[40%] bg-indigo-900 p-8 md:p-10 text-white flex flex-col relative overflow-hidden shrink-0">
          <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
             <div className="absolute top-[-10%] right-[-10%] w-64 h-64 bg-white rounded-full blur-3xl"></div>
             <div className="absolute bottom-[-10%] left-[-10%] w-64 h-64 bg-indigo-400 rounded-full blur-3xl"></div>
          </div>
          
          <div className="relative z-10 flex items-center gap-2 mb-12">
            <Globe className="text-indigo-300 w-5 h-5" />
            <span className="font-bold text-indigo-300/60 text-[10px] uppercase tracking-[0.2em]">SiteFinder Global</span>
          </div>
          
          <div className="relative z-10 flex-1">
            <h2 className="text-4xl font-black tracking-tighter mb-4 leading-tight">Elite Scout<br/>Pass</h2>
            <p className="text-indigo-200/60 text-sm mb-10 leading-relaxed font-medium">Unrestricted access to the world's most powerful business discovery engine.</p>
            
            <div className="space-y-6 mb-12">
              {[
                { label: 'Unlimited Leads', desc: 'No scan limits ever' },
                { label: 'Hyper-Intelligence', desc: 'Full business DNA breakdown' },
                { label: 'Priority Server', desc: '2x faster AI processing' }
              ].map(f => (
                <div key={f.label} className="flex gap-4">
                  <div className="mt-1 w-5 h-5 bg-white/10 text-indigo-300 rounded-full flex items-center justify-center shrink-0 border border-white/5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-white tracking-tight">{f.label}</p>
                    <p className="text-xs text-indigo-200/40 font-medium">{f.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="relative z-10 pt-8 border-t border-white/10">
            <div className="flex justify-between items-end">
              <div>
                <p className="text-[10px] font-bold text-indigo-300/40 uppercase tracking-widest mb-1">Lifetime Pass</p>
                <div className="flex items-baseline gap-2">
                   <p className="text-4xl font-black text-white">Rs. 2,500</p>
                   <span className="text-indigo-300/40 text-xs font-bold">$9.00 USD</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right Side: Payment Methods */}
        <div className="flex-1 p-8 md:p-12 relative bg-white text-slate-900 overflow-y-auto custom-scrollbar">
          <button onClick={onClose} className="absolute top-8 right-8 p-2 hover:bg-slate-100 rounded-full transition-all hover:rotate-90 z-20">
            <X className="w-5 h-5 text-slate-300" />
          </button>

          <div className="max-w-md mx-auto h-full flex flex-col">
            <div className="flex items-center gap-2 mb-10">
              <div className="w-2 h-2 rounded-full bg-indigo-600 animate-pulse"></div>
              <span className="text-xs font-black text-slate-900 uppercase tracking-widest">Payment Gateway</span>
            </div>

            {step === 1 ? (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex-1">
                <h3 className="text-2xl font-bold mb-8 text-slate-900 tracking-tight">Select Transfer Method</h3>
                <div className="space-y-4 mb-10">
                  <button 
                    onClick={() => setMethod('jazz')}
                    className={`w-full p-5 rounded-[24px] flex items-center justify-between transition-all border-2 ${method === 'jazz' ? 'bg-indigo-50 border-indigo-600' : 'bg-white border-slate-100 hover:border-slate-200'}`}
                  >
                    <div className="flex items-center gap-5">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-[10px] uppercase ${method === 'jazz' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-slate-100 text-slate-400'}`}>
                        PK Bank
                      </div>
                      <div className="text-left">
                        <p className={`font-bold text-sm ${method === 'jazz' ? 'text-indigo-900' : 'text-slate-600'}`}>JazzCash / Bank Transfer</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Fast Local Processing</p>
                      </div>
                    </div>
                    {method === 'jazz' && <CheckCircle2 className="text-indigo-600 w-6 h-6" />}
                  </button>

                  <button 
                    onClick={() => setMethod('card')}
                    className={`w-full p-5 rounded-[24px] flex items-center justify-between transition-all border-2 ${method === 'card' ? 'bg-indigo-50 border-indigo-600' : 'bg-white border-slate-100 hover:border-slate-200'}`}
                  >
                    <div className="flex items-center gap-5">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-[10px] uppercase ${method === 'card' ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-100' : 'bg-slate-100 text-slate-400'}`}>
                        <CreditCard className="w-6 h-6" />
                      </div>
                      <div className="text-left">
                        <p className={`font-bold text-sm ${method === 'card' ? 'text-indigo-900' : 'text-slate-600'}`}>Credit / Debit Card</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Instant Form Processing</p>
                      </div>
                    </div>
                    {method === 'card' && <CheckCircle2 className="text-indigo-600 w-6 h-6" />}
                  </button>

                  <button 
                    onClick={() => setMethod('crypto')}
                    className={`w-full p-5 rounded-[24px] flex items-center justify-between transition-all border-2 ${method === 'crypto' ? 'bg-slate-900 border-slate-900 text-white' : 'bg-white border-slate-100 hover:border-slate-200'}`}
                  >
                    <div className="flex items-center gap-5">
                      <div className={`w-14 h-14 rounded-2xl flex items-center justify-center font-black text-[10px] uppercase ${method === 'crypto' ? 'bg-white text-slate-900' : 'bg-slate-100 text-slate-400'}`}>
                        <Bitcoin className="w-6 h-6" />
                      </div>
                      <div className="text-left">
                        <p className={`font-bold text-sm ${method === 'crypto' ? 'text-white' : 'text-slate-600'}`}>Crypto Checkout</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">BTC / USDT / ETH</p>
                      </div>
                    </div>
                    {method === 'crypto' && <CheckCircle2 className="text-white w-6 h-6" />}
                  </button>
                </div>

                <div className="bg-slate-50 rounded-[32px] p-8 border border-slate-100 mb-10">
                   {method === 'crypto' ? (
                     <>
                        <div className="flex items-center gap-2 mb-4">
                          <Coins className="w-4 h-4 text-amber-500" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Merchant Wallet</span>
                        </div>
                        <p className="text-xs font-bold text-slate-900 mb-2">USDT (TRC20):</p>
                        <div className="bg-white p-4 rounded-xl border border-slate-200 font-mono text-sm tracking-tighter flex items-center justify-between group shadow-sm overflow-hidden">
                          <span className="text-slate-900 truncate mr-4">TYG9j...v8Xz2q</span>
                          <button onClick={() => { navigator.clipboard.writeText('TYG9j...v8Xz2q'); alert('Wallet Copied!'); }} className="p-2 hover:bg-slate-50 rounded-lg">
                            <Copy className="w-4 h-4 text-slate-300 group-hover:text-amber-500 transition-colors cursor-pointer shrink-0" />
                          </button>
                        </div>
                     </>
                   ) : method === 'card' ? (
                     <div className="space-y-4">
                        <div className="flex items-center gap-2 mb-2">
                          <ShieldCheck className="w-4 h-4 text-emerald-600" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Card Processor</span>
                        </div>
                        <div className="space-y-2 text-slate-900">
                           <input type="text" placeholder="Card Number" className="w-full p-3 bg-white border border-slate-200 rounded-xl text-sm" />
                           <div className="flex gap-2">
                              <input type="text" placeholder="MM/YY" className="w-1/2 p-3 bg-white border border-slate-200 rounded-xl text-sm" />
                              <input type="text" placeholder="CVC" className="w-1/2 p-3 bg-white border border-slate-200 rounded-xl text-sm" />
                           </div>
                        </div>
                        <p className="text-[10px] text-slate-400 leading-tight">Your card will be authorized for Rs. 2,500. Verification via bank statement ID is required after auth.</p>
                     </div>
                   ) : (
                     <>
                        <div className="flex items-center gap-2 mb-4">
                          <Landmark className="w-4 h-4 text-indigo-600" />
                          <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-400">Account Details</span>
                        </div>
                        <p className="text-xs font-bold text-slate-900 mb-2">IBAN Transfer:</p>
                        <div className="bg-white p-4 rounded-xl border border-slate-200 font-mono text-sm tracking-tighter flex items-center justify-between group shadow-sm">
                          <span className="text-slate-900">{maskedIban}</span>
                          <button onClick={() => { navigator.clipboard.writeText(iban); alert('Full IBAN Copied!'); }} className="p-2 hover:bg-slate-50 rounded-lg">
                            <Copy className="w-4 h-4 text-slate-300 group-hover:text-indigo-600 transition-colors cursor-pointer" />
                          </button>
                        </div>
                     </>
                   )}
                </div>

                {!user ? (
                   <button 
                    onClick={loginWithGoogle}
                    className="w-full bg-indigo-600 text-white py-5 rounded-[24px] font-bold flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 active:scale-[0.98]"
                  >
                    <LogIn className="w-5 h-5" /> Login to Continue
                  </button>
                ) : (
                  <button 
                    onClick={() => setStep(2)}
                    className="w-full bg-slate-900 text-white py-5 rounded-[24px] font-bold flex items-center justify-center gap-3 hover:bg-black transition-all shadow-xl shadow-slate-200 active:scale-[0.98]"
                  >
                    {method === 'card' ? 'Authorize Card' : "I've sent the payment"} <ArrowRight className="w-5 h-5" />
                  </button>
                )}
              </motion.div>
            ) : (
              <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} className="flex-1">
                <button onClick={() => setStep(1)} className="text-indigo-600 text-[10px] font-black uppercase tracking-widest mb-6 block hover:opacity-70 transition-opacity">← Back to methods</button>
                <h3 className="text-2xl font-bold mb-4 text-slate-900 tracking-tight">Receipt Verification</h3>
                <p className="text-sm text-slate-500 mb-10 leading-relaxed font-medium">
                  {method === 'card' 
                    ? "Enter your bank's Transaction ID (TID) or Statement Code to finalize the Elite Scout Pass unlock." 
                    : "We verify every transaction manually. Enter your ID below and we'll confirm it against our logs."}
                </p>

                <div className="space-y-8 mb-12">
                  <div className="space-y-3">
                    <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block pl-1">Transaction ID / Hash</label>
                    <input 
                      type="text" 
                      placeholder={method === 'jazz' ? "e.g. 05442938120" : method === 'card' ? "Auth Code / TID" : "e.g. 0x71c...a3e"}
                      className="w-full p-5 bg-slate-50 border border-slate-200 rounded-[24px] outline-none focus:ring-4 focus:ring-indigo-500/10 font-mono text-sm transition-all text-slate-900"
                      value={tid}
                      onChange={(e) => setTid(e.target.value)}
                    />
                  </div>
                </div>

                <div className="mt-auto">
                  <button 
                    onClick={handleVerify}
                    disabled={isVerifying || !tid}
                    className="w-full bg-indigo-600 text-white py-5 rounded-[24px] font-bold flex items-center justify-center gap-3 hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-xl shadow-indigo-100 active:scale-[0.98]"
                  >
                    {isVerifying ? <Loader2 className="animate-spin w-5 h-5" /> : <Zap className="w-5 h-5" />}
                    {isVerifying ? 'Confirming Transaction...' : 'Verify Transfer'}
                  </button>
                  <p className="text-center text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-6">
                    <ShieldCheck className="w-3 h-3 inline mr-1 text-emerald-500" />
                    Encrypted Verification Secure
                  </p>
                </div>
              </motion.div>
            )}
          </div>
        </div>

      </motion.div>
    </motion.div>
  );
};

export default function App() {
  const [view, setView] = useState<'findLeads' | 'promptSiter'>('findLeads');
  const [niche, setNiche] = useState('');
  const [location, setLocation] = useState('');
  const [mapsUrl, setMapsUrl] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [leads, setLeads] = useState<BusinessLead[]>([]);
  const [review, setReview] = useState<BusinessReview | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  // --- Firebase User & Payment States ---
  const [user, setUser] = useState<User | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [showCheckout, setShowCheckout] = useState(false);

  useEffect(() => {
    return auth.onAuthStateChanged((u) => {
      setUser(u);
      if (u) {
        syncUser(u, setUserData);
      } else {
        setUserData(null);
      }
    });
  }, []);

  const isPaid = userData?.isPaid || false;
  const trialEnd = userData?.trialStart ? userData.trialStart + 7 * 24 * 60 * 60 * 1000 : null;

  const isTrialActive = () => {
    if (!trialEnd) return true;
    return Date.now() < trialEnd;
  };

  const deductScan = () => {
    if (isPaid) return true;
    if (!isTrialActive()) {
      setShowCheckout(true);
      return false;
    }
    return true;
  };

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!niche || !location) return;
    if (!deductScan()) return;

    setIsLoading(true);
    setHasSearched(true);
    try {
      const results = await findNoWebBusinesses(niche, location);
      setLeads(results);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleReview = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!mapsUrl) return;
    if (!deductScan()) return;

    setIsLoading(true);
    try {
      const result = await reviewBusinessFromUrl(mapsUrl);
      setReview(result);
    } catch (err) {
      console.error(err);
    } finally {
      setIsLoading(false);
    }
  };

  const getTrialDaysLeft = () => {
    if (!trialEnd) return 7;
    const diff = trialEnd - Date.now();
    return Math.max(0, Math.ceil(diff / (24 * 60 * 60 * 1000)));
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 font-sans selection:bg-indigo-100 relative">
      <AnimatePresence>
        {showCheckout && (
          <CheckoutPage 
            user={user}
            iban="PK65JCMA0404923323390624" 
            onClose={() => setShowCheckout(false)} 
            onPaymentSuccess={() => {}} 
          />
        )}
      </AnimatePresence>

      {/* Header */}
      <header className="h-20 bg-white border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-sm shadow-indigo-100">
                <Globe className="text-white w-6 h-6" />
              </div>
              <div>
                <h1 className="text-xl font-black tracking-tighter text-slate-900 leading-none">SiteFinder</h1>
                <p className="text-[9px] uppercase tracking-[0.3em] text-indigo-600 font-black mt-1">Global Intelligence</p>
              </div>
            </div>
            
            <nav className="hidden md:flex items-center gap-1 bg-slate-50 p-1.5 rounded-2xl border border-slate-100 text-slate-900">
              <button 
                onClick={() => setView('findLeads')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${view === 'findLeads' ? 'bg-white text-indigo-600 shadow-xl shadow-indigo-100' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <Search className="w-3.5 h-3.5" />
                Find Leads
              </button>
              <button 
                onClick={() => setView('promptSiter')}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs font-bold transition-all ${view === 'promptSiter' ? 'bg-white text-indigo-600 shadow-xl shadow-indigo-100' : 'text-slate-400 hover:text-slate-600'}`}
              >
                <Layout className="w-3.5 h-3.5" />
                Prompt Siter
              </button>
            </nav>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <div className="flex items-center gap-4 py-2 px-4 bg-slate-50 border border-slate-100 rounded-2xl">
              <div className="flex flex-col items-start pr-4 border-r border-slate-200">
                <span className="text-[9px] font-black text-slate-400 uppercase tracking-widest mb-0.5">
                  Subscription
                </span>
                <span className={`text-xs font-black uppercase tracking-tighter ${isPaid ? 'text-emerald-600' : 'text-indigo-600'}`}>
                  {isPaid ? 'Elite Scout' : `${getTrialDaysLeft()} Day Trial`}
                </span>
              </div>
              {!isPaid && (
                <button 
                  onClick={() => setShowCheckout(true)}
                  className="group flex items-center gap-2 text-[10px] font-black text-slate-900 uppercase tracking-widest hover:text-indigo-600 transition-colors"
                >
                  Go Elite <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
                </button>
              )}
              {isPaid && <ShieldCheck className="w-5 h-5 text-emerald-500" />}
            </div>
            
            <div className="flex items-center gap-3">
               {user ? (
                 <div className="flex items-center gap-3 pl-4 border-l border-slate-200">
                   <div className="flex flex-col items-end">
                     <span className="text-[10px] font-black text-slate-900 tracking-tighter leading-none">{user.displayName}</span>
                     <button onClick={logout} className="text-[8px] font-bold text-slate-400 uppercase hover:text-indigo-600 transition-colors">Sign Out</button>
                   </div>
                   {user.photoURL ? (
                     <img src={user.photoURL} alt="Avatar" className="w-8 h-8 rounded-lg" referrerPolicy="no-referrer" />
                   ) : (
                     <div className="w-8 h-8 rounded-lg bg-indigo-100 flex items-center justify-center text-indigo-600">
                        <UserIcon className="w-4 h-4" />
                     </div>
                   )}
                 </div>
               ) : (
                 <button onClick={loginWithGoogle} className="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white text-[10px] font-black uppercase tracking-widest rounded-xl hover:bg-black transition-all">
                    <LogIn className="w-3 h-3" /> Login
                 </button>
               )}
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-12">
        {view === 'findLeads' ? (
          <>
            {/* Search Hero */}
            <section className="mb-16">
              <div className="max-w-3xl">
                <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6 leading-[1.1] text-slate-900">
                  Find businesses that <span className="text-indigo-600">don't exist</span> online yet.
                </h2>
                <p className="text-lg text-slate-500 mb-10 leading-relaxed max-w-2xl">
                  Target hyper-local businesses and services that only have a physical presence. 
                  Our engine cross-references global directories to find 100% offline-only leads.
                </p>

                <form onSubmit={handleSearch} className="flex flex-col md:flex-row gap-4 p-3 bg-white rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex-1 flex items-center px-4 py-3 gap-3 bg-slate-50 border border-slate-100 rounded-xl">
                    <Building2 className="w-5 h-5 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Niche (e.g. Italian Restaurant)" 
                      className="w-full bg-transparent outline-none font-medium placeholder:text-slate-300 text-sm"
                      value={niche}
                      onChange={(e) => setNiche(e.target.value)}
                      required
                    />
                  </div>
                  <div className="flex-1 flex items-center px-4 py-3 gap-3 bg-slate-50 border border-slate-100 rounded-xl">
                    <MapPin className="w-5 h-5 text-slate-400" />
                    <input 
                      type="text" 
                      placeholder="Location (e.g. Austin, TX)" 
                      className="w-full bg-transparent outline-none font-medium placeholder:text-slate-300 text-sm"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      required
                    />
                  </div>
                  <button 
                    disabled={isLoading}
                    className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-lg shadow-indigo-100"
                  >
                    {isLoading ? <Loader2 className="animate-spin w-5 h-5" /> : <Search className="w-5 h-5" />}
                    {isLoading ? 'Scanning...' : 'Scan Leads'}
                  </button>
                </form>
              </div>
            </section>

            {/* Results Area */}
            <AnimatePresence mode="wait">
              {isLoading ? (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="py-32 flex flex-col items-center justify-center gap-4 text-center"
                >
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-slate-100 border-t-indigo-600 rounded-full animate-spin" />
                    <Globe className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-indigo-600 animate-pulse" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">Scanning global registries...</p>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">Verified Offline Filter Active</p>
                  </div>
                </motion.div>
              ) : leads.length > 0 ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <div className="flex items-center justify-between px-4 mb-4">
                    <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Discovered Leads ({leads.length})</h3>
                    <div className="flex items-center gap-2">
                      <div className="h-1.5 w-32 bg-slate-100 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 w-full"></div>
                      </div>
                      <span className="text-[10px] font-bold text-emerald-600 uppercase">100% Confirmed</span>
                    </div>
                  </div>

                  <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
                    {leads.map((lead, idx) => (
                      <motion.div 
                        key={lead.name}
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        transition={{ delay: idx * 0.05 }}
                        className={`grid grid-cols-1 md:grid-cols-6 px-8 py-6 items-center gap-6 border-b border-slate-50 hover:bg-slate-50 transition-colors ${idx === leads.length - 1 ? 'border-b-0' : ''}`}
                      >
                        <div className="md:col-span-2">
                          <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors uppercase tracking-tight">
                            {lead.name}
                          </h4>
                          <div className="flex items-center gap-1.5 mt-1">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            <span className="text-xs text-slate-500">{lead.address}</span>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
                          <span className="text-xs font-bold text-emerald-600">{lead.confidenceScore}% Verified</span>
                        </div>

                        <div className="flex flex-col">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter mb-1">Contact Details</span>
                          <span className="text-xs text-slate-600 font-mono tracking-tight">{lead.phone}</span>
                        </div>

                        <div className="flex flex-col">
                          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter mb-1">AI Recommendation</span>
                          <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-1 rounded-md w-fit font-semibold">
                            {lead.contactStrategy.split(' ').slice(0, 2).join(' ')}
                          </span>
                        </div>

                        <div className="flex justify-end">
                          <button 
                            onClick={() => alert(`Full Analysis: ${lead.whyNoWebsite}`)}
                            className="p-2 hover:bg-slate-100 rounded-lg transition-colors text-slate-400 hover:text-indigo-600"
                          >
                            <Info className="w-5 h-5" />
                          </button>
                        </div>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              ) : hasSearched ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="py-32 text-center"
                >
                  <ShieldAlert className="w-12 h-12 mx-auto mb-4 text-slate-200" />
                  <p className="text-xl font-bold text-slate-900">No matching leads found.</p>
                  <p className="text-sm text-slate-400 mt-2">Try adjusting your niche or broadening the scan region.</p>
                </motion.div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="py-12 flex flex-col items-center"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 w-full opacity-40">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="bg-white border border-slate-200 rounded-2xl h-32 flex flex-col items-center justify-center p-6 border-dashed">
                        <div className="w-full h-2 bg-slate-100 rounded-full mb-4"></div>
                        <div className="w-1/2 h-2 bg-slate-50 rounded-full"></div>
                      </div>
                    ))}
                  </div>
                  <div className="mt-12 p-6 bg-indigo-50 rounded-2xl border border-indigo-100 max-w-sm text-center">
                    <p className="text-xs text-indigo-700 font-bold uppercase tracking-widest mb-2">Scanner Ready</p>
                    <p className="text-sm text-indigo-900 leading-relaxed">Enter a niche and location to begin the global discovery process.</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        ) : (
          <>
            {/* Prompt Siter View */}
            <section className="mb-16">
              <div className="max-w-3xl">
                <span className="inline-flex items-center gap-2 px-3 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-bold uppercase tracking-widest rounded-full mb-6">
                  <Sparkles className="w-3 h-3" />
                  New Tool: Prompt Siter
                </span>
                <h2 className="text-5xl md:text-6xl font-bold tracking-tight mb-6 leading-[1.1] text-slate-900">
                  Turn a link into a <span className="text-indigo-600">full site blueprint.</span>
                </h2>
                <p className="text-lg text-slate-500 mb-10 leading-relaxed max-w-2xl">
                  Paste a Google Maps or directory link. AI will dissect every service, review, and detail to create a structured JSON for any site builder.
                </p>

                <form onSubmit={handleReview} className="flex flex-col md:flex-row gap-4 p-3 bg-white rounded-2xl shadow-sm border border-slate-200">
                  <div className="flex-1 flex items-center px-4 py-3 gap-3 bg-slate-50 border border-slate-100 rounded-xl">
                    <LinkIcon className="w-5 h-5 text-slate-400" />
                    <input 
                      type="url" 
                      placeholder="Paste Google Maps URL here..." 
                      className="w-full bg-transparent outline-none font-medium placeholder:text-slate-300 text-sm"
                      value={mapsUrl}
                      onChange={(e) => setMapsUrl(e.target.value)}
                      required
                    />
                  </div>
                  <button 
                    disabled={isLoading}
                    className="bg-indigo-600 text-white px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 hover:bg-indigo-700 transition-all disabled:opacity-50 shadow-lg shadow-indigo-100"
                  >
                    {isLoading ? <Loader2 className="animate-spin w-5 h-5" /> : <Rocket className="w-5 h-5" />}
                    {isLoading ? 'Analyzing...' : 'Generate Blueprint'}
                  </button>
                </form>
              </div>
            </section>

            <AnimatePresence mode="wait">
              {isLoading ? (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  className="py-32 flex flex-col items-center justify-center gap-4 text-center"
                >
                  <div className="relative">
                    <div className="w-16 h-16 border-4 border-slate-100 border-t-indigo-600 rounded-full animate-spin" />
                    <Sparkles className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-6 h-6 text-indigo-600 animate-pulse" />
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">AI is visiting the business virtually...</p>
                    <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-2">Extracting Services & Reviews</p>
                  </div>
                </motion.div>
              ) : review ? (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="grid grid-cols-1 lg:grid-cols-3 gap-8"
                >
                  {/* JSON Output */}
                  <div className="lg:col-span-2">
                    <div className="bg-slate-900 rounded-3xl p-8 text-indigo-300 font-mono text-xs overflow-hidden shadow-2xl relative">
                      <div className="flex items-center justify-between mb-4 pb-4 border-b border-white/10">
                        <div className="flex items-center gap-2">
                          <Code className="w-4 h-4" />
                          <span className="uppercase tracking-widest font-bold opacity-50">Site Structure (JSON)</span>
                        </div>
                        <button 
                          onClick={() => {
                            navigator.clipboard.writeText(JSON.stringify(review, null, 2));
                            alert('Copied to clipboard!');
                          }}
                          className="flex items-center gap-1.5 px-3 py-1.5 bg-white/5 rounded-lg hover:bg-white/10 transition-colors"
                        >
                          <Copy className="w-3 h-3" />
                          Copy
                        </button>
                      </div>
                      <pre className="max-h-[500px] overflow-auto custom-scrollbar leading-relaxed">
                        {JSON.stringify(review, null, 2)}
                      </pre>
                    </div>
                  </div>

                  {/* Recommendations */}
                  <div className="space-y-6">
                    <div className="bg-white border border-slate-200 rounded-3xl p-8 shadow-sm">
                      <h3 className="text-sm font-bold text-slate-900 uppercase tracking-tight mb-6 flex items-center gap-2">
                        <Rocket className="w-4 h-4 text-indigo-600" />
                        Viba Deployment
                      </h3>
                      <p className="text-xs text-slate-500 mb-6 leading-relaxed">
                        Use these site builders to upload the JSON blueprint above or prompt your way to a site:
                      </p>
                      
                      <div className="space-y-4">
                        {[
                          { name: 'Vibe Coding / Vike', desc: 'Modern reactive site generation', link: 'https://vike.dev' },
                          { name: 'Relume AI', desc: 'AI visual site mapping', link: 'https://relume.io' },
                          { name: 'Framer AI', desc: 'Interactive prompt-to-site', link: 'https://framer.com' },
                          { name: 'Siter.io', desc: 'Design-friendly site builder', link: 'https://siter.io' }
                        ].map(site => (
                          <a 
                            key={site.name} 
                            href={site.link} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="block p-4 rounded-2xl bg-slate-50 border border-slate-100 hover:border-indigo-200 hover:bg-white transition-all group"
                          >
                            <h4 className="text-sm font-bold text-slate-900 group-hover:text-indigo-600 transition-colors">{site.name}</h4>
                            <p className="text-[10px] text-slate-400 font-bold uppercase mt-1 tracking-tighter">{site.desc}</p>
                          </a>
                        ))}
                      </div>
                    </div>

                    <div className="bg-indigo-600 rounded-3xl p-8 text-white">
                      <h4 className="font-bold mb-2">Pro Tip:</h4>
                      <p className="text-sm opacity-80 leading-relaxed mb-6">
                        Copy the JSON and paste it into a ChatGPT or Claude prompt: "Build me a React component based on this business data."
                      </p>
                      <img 
                        src="https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=400&auto=format&fit=crop&q=60" 
                        alt="Web Development"
                        className="w-full h-32 object-cover rounded-xl opacity-50 grayscale blend-overlay"
                      />
                    </div>
                  </div>
                </motion.div>
              ) : (
                <motion.div 
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="py-12 flex flex-col items-center"
                >
                  <div className="p-8 bg-white border-2 border-dashed border-slate-200 rounded-3xl max-w-sm w-full text-center opacity-40">
                    <LinkIcon className="w-8 h-8 mx-auto mb-4" />
                    <p className="text-xs font-bold uppercase tracking-widest leading-loose">Waiting for URL analysis</p>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </>
        )}
      </main>

      <footer className="max-w-7xl mx-auto px-6 py-12 border-t border-slate-200 flex flex-col md:flex-row justify-between items-center gap-4 text-slate-400">
        <div className="flex gap-8">
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Architecture</span>
            <span className="text-xs font-bold text-slate-500">Global Cluster v4</span>
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-300">Data Source</span>
            <span className="text-xs font-bold text-slate-500">Live Directories</span>
          </div>
        </div>
        <p className="text-[10px] font-bold uppercase tracking-tighter">© 2024 SITEFINDER • ENHANCED LEAD INTELLIGENCE</p>
      </footer>
    </div>
  );
}
